# Spendwise (offline Android app)
Everything runs on the phone. No server, no internet needed (PDF reader is bundled in www/lib).

## Get the APK without installing anything
1. Create a free GitHub account, make a new private repository.
2. Upload ALL files from this folder (keep the .github folder).
3. Open the repository, Actions tab, Build APK, wait about 5 minutes.
4. Open the finished run, download the "Spendwise-APK" file, unzip, copy app-debug.apk to your phone and install it (allow "install unknown apps").

## Build on a computer instead
Install Node 20 and Android Studio, then: npm install, npx cap sync android, cd android, ./gradlew assembleDebug.
The APK is at android/app/build/outputs/apk/debug/app-debug.apk.

## Change the app
Edit www/index.html, then run npx cap sync android and rebuild.
