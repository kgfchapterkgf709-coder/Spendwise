async function parsePDF(buf,kind,lib){
 const mp=kind==='mp',dre=mp?/^\d\d-\d\d-\d{4}$/:/^\d\d\/\d\d\/\d{4}$/,sp=mp?'-':'/';
 const pdf=await lib.getDocument({data:buf}).promise,out=[];let cur=null,lastY=null;
 for(let p=1;p<=pdf.numPages;p++){
  const tc=await(await pdf.getPage(p)).getTextContent();
  const it=tc.items.filter(i=>i.str.trim()&&Math.abs(i.transform[1])<.1).map(i=>({s:i.str.trim(),x:i.transform[4],y:Math.round(i.transform[5]),r:i.transform[4]+i.width}));
  const dh=it.find(i=>i.s==='Debit'),ch=it.find(i=>i.s==='Credit');if(!dh||!ch)continue;
  const pos=i=>mp?(i.x+i.r)/2:i.r,cut=mp?ch.x*.18:dh.x*.2;
  const ft=it.find(i=>/^(The items and|Note:|Page \d)/.test(i.s));
  const body=it.filter(i=>i.y<dh.y-2&&(!ft||i.y>ft.y+2)).map(i=>({...i,k:i.y+(dre.test(i.s)&&i.x<cut?4:0)})).sort((a,b)=>b.k-a.k||a.x-b.x);lastY=null;
  for(const i of body){
   if(dre.test(i.s)&&i.x<cut){const[d,m,y]=i.s.split(sp);cur={date:`${y}-${m}-${d}`,lines:[],money:[]};out.push(cur);lastY=null;continue}
   if(!cur)continue;
   if(/^\d{1,3}(,\d{3})*\.\d{2}$/.test(i.s)&&i.x>(mp?ch.x-40:dh.x-130)){cur.money.push({v:parseFloat(i.s.replace(/,/g,'')),cr:Math.abs(pos(i)-pos(ch))<Math.abs(pos(i)-pos(dh))});continue}
   if(i.x<cut||i.r>=(mp?ch.x:dh.x)-5)continue;
   if(lastY===null||Math.abs(i.y-lastY)>3)cur.lines.push(i.s);else cur.lines[cur.lines.length-1]+=' '+i.s;lastY=i.y}}
 return out.filter(t=>t.money.length>=2).map(t=>{
  const a=t.money[0],b=t.money[t.money.length-1].v,amt=a.cr?a.v:-a.v,lines=t.lines.filter(l=>!/^(Note:|Should you)/.test(l));
  const j=lines.join(' | '),tid=(j.match(/Txn ID:\s*(\d+)/)||[])[1];
  const desc=mp?(lines.filter(l=>!/^Txn ID/.test(l))[0]||''):j;
  return{id:mp&&tid?'mp'+tid:`${t.date}|${amt}|${b}`,date:t.date,desc,amt,bal:b,src:kind}})}
if(typeof module!=='undefined')module.exports={parsePDF};
